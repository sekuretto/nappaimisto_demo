(function () {
    function contentLoaded () {
        var lisatyt = [];
        var poistetut = [];
        var tilanne = [];
        var kaikki = [];
        a = 0;
        lisatytdiv = document.getElementById('lisatyt');
        poistetutdiv = document.getElementById('poistetut');
        tilannediv = document.getElementById('tilanne');

        window.addEventListener('keyup', function (e) {
            //lisätyt taulukko
            if (e.keyCode >= 46 && e.keyCode <= 90) {
                lisatyt.push(e.key);
                lisatytdiv.textContent = lisatyt.join('');
                //console.log(chars);

            //poistetut
            }else if (e.keyCode === 8){
                for(i = 0; i < 1 ; i++){  
                    char = lisatyt.join('');
                    var res = char.charAt(a);
                    poistetut.push(res);
                    poistetutdiv.textContent = poistetut.join('');
                    //console.log(res);
                    kaikki.shift();
                    $("tilanne").empty();
                    tilannediv.textContent = kaikki.join('');
                    a++;
                }
                
            //tilanne
            }if(e.keyCode >= 46 && e.keyCode <= 90){
                kaikki.push(e.key);
                if(e.keyCode === 8) {   
                }
                tilannediv.textContent = kaikki.join('');
                }
        }, false);
    }
    window.addEventListener('DOMContentLoaded', contentLoaded, false); 
}());


//painettu näppäin
function myKeyPress(e){
    var keynum;

    if(window.event) { // IE                    
      keynum = e.keyCode;
    } else if(e.which){ // Netscape/Firefox/Opera                   
      keynum = e.which;
    }

    painettu = document.getElementById('painettu');
    painettu.textContent = (String.fromCharCode(keynum));
}
